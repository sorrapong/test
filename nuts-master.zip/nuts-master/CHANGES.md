# Release notes
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

### 3.0.0
- Rewrite to be cleaner
- Support for other backends than GitHub
- Better disk caching

### 2.6.0
- Add `/notes` endpoint to get changelog
- GitHub authentication is now optional for public repos (Thanks @ide)
